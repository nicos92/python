def sumar(num1, num2):
    return num1 + num2


def restar(num1, num2):
    return num1 - num2


def multiplicar(num1, num2):
    return num1 * num2
def divir(num1, num2):
    return num1 / num2
def potencia(num1, num2):
    return num1 ** num2
def redondear(num1):
    return round(num1)
