from setuptools import setup

setup(
    name="paquetecalculos",
    version="0.1",
    description="Paquete de calculos basicos",
    author="nicos92",
    author_email="nicolassandoval140692@gmail.com",
    url="https://nicolassandoval.com",
    packages=["calculos","calculos.calculosbasicos"]


)